const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');

const Role = sequelize.define('Role', {
    role_name: { type: DataTypes.STRING(30), allowNull: false, unique: true },
    permissions: { type: DataTypes.JSON, allowNull: false },
});

module.exports = Role;
