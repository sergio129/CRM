const bcrypt = require('bcrypt');
const User = require('../models/User');

exports.createUser = async (req, res) => {
    const { full_name, email, username, password, role } = req.body;

    try {
        const passwordHash = await bcrypt.hash(password, 10);
        const newUser = await User.create({ full_name, email, username, password_hash: passwordHash, role });

        res.status(201).json({ message: 'Usuario creado exitosamente', user: newUser });
    } catch (error) {
        res.status(500).json({ message: 'Error al crear usuario', error });
    }
};

exports.getUsers = async (req, res) => {
    try {
        const users = await User.findAll({
            attributes: ['id', 'full_name', 'email', 'username', 'role', 'status']
        });
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener los usuarios', error });
    }
};

// Obtener usuario por ID
exports.getUserById = async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id, {
            attributes: ['id', 'full_name', 'email', 'username', 'role', 'status']
        });

        if (!user) return res.status(404).json({ message: "Usuario no encontrado" });

        res.json(user);
    } catch (error) {
        res.status(500).json({ message: "Error al obtener el usuario", error });
    }
};

// Crear un nuevo usuario
exports.createUser = async (req, res) => {
    try {
        const { full_name, email, username, password, role, status } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
          // Validar que los campos requeridos estén presentes
          if (!full_name || !email || !username || !password || !role || !status) {
            return res.status(400).json({ message: "Todos los campos son obligatorios" });
        }
   // Crear el usuario en la base de datos
        const newUser = await User.create({
            full_name,
            email,
            username,
            password_hash: hashedPassword,
            role,
            status
        });

        res.status(201).json({ message: "Usuario creado correctamente", user: newUser });
    } catch (error) {
        res.status(500).json({ message: "Error al crear el usuario", error });
    }
};

// Actualizar usuario
exports.updateUser = async (req, res) => {
    try {
        const { full_name, email, username, role, status } = req.body;

        const user = await User.findByPk(req.params.id);
        if (!user) return res.status(404).json({ message: "Usuario no encontrado" });

        await user.update({ full_name, email, username, role, status });

        res.json({ message: "Usuario actualizado correctamente", user });
    } catch (error) {
        res.status(500).json({ message: "Error al actualizar el usuario", error });
    }
};

// Eliminar usuario
exports.deleteUser = async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        if (!user) return res.status(404).json({ message: "Usuario no encontrado" });

        await user.destroy();
        res.json({ message: "Usuario eliminado correctamente" });
    } catch (error) {
        res.status(500).json({ message: "Error al eliminar el usuario", error });
    }
};

// Buscar usuario por nombre de usuario
exports.searchUser = async (req, res) => {
    try {
        const users = await User.findAll({
            where: { username: req.params.username },
            attributes: ['id', 'full_name', 'email', 'username', 'role', 'status']
        });

        if (users.length === 0) {
            return res.status(404).json({ message: "No se encontraron usuarios con ese nombre" });
        }

        res.json(users);
    } catch (error) {
        res.status(500).json({ message: "Error al buscar usuario", error });
    }
};